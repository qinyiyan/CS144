-- dropSQLIndex.sql
DROP TABLE IF EXISTS ItemLocation;